<template>
<div class="container">
    <div class="row">
        <div class="col">
            <img src="../assets/loading.gif" alt="" class="d-block m-auto">
        </div>
    </div>
</div>

</template>

<script>

export default {

    name: 'mySpinner',
}

</script>

<style scoped>

</style>