<template>
    <div>
        <h2>Home Component</h2>
        <button class="btn btn-primary">Hello</button>
        <i class="fa fa-home fa-4x text-danger"></i>
    </div>
</template>

<script>

export default {

    name: 'homePg',
}

</script>

<style scoped></style>