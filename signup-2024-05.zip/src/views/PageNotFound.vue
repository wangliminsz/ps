<template>
    <div class="container text-center mt-3">
        <div class="row">
            <div class="col">
                <h2 class="text-danger">404! Page Not Found</h2>
            </div>
        </div>
    </div>
</template>

<script>

export default {

    name: 'PageNotFound',
}

</script>

<style scoped>

</style>